 "use strict";
 
  function success(argument) {
    window.location.href = $('#location_url').val();
  }